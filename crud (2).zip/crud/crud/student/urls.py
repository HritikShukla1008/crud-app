from django.urls import path
from student import views

urlpatterns = [
    path('', views.home),
    path('display', views.display),
    path('discard/<str:roll>', views.discard)
]