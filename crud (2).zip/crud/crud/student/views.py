from django.shortcuts import render,redirect
from student.models import Student
# Create your views here.

def home(request):
    if request.method == 'POST':
        name = request.POST['sName']
        roll = request.POST['sRoll']
        email = request.POST['sEmail']
        mob = request.POST['sMob']
        pwd = request.POST['sPassword']
        print(name, roll, email, mob, pwd)
        stud = Student(name=name, roll = roll, email = email, mob = mob, pwd = pwd)
        stud.save()
    
    return render(request, 'home.html')
    

def display(request):
    students = Student.objects.all()
    return render(request, 'display.html', {'students': students})

def discard(request, roll):
    student = Student.objects.get(roll = roll)
    student.delete()

    return redirect('/display')